// Modified frontend call to your backend
return fetch('/api/scan', {
    method: 'POST',
    body: formData
});