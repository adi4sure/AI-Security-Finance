import asyncio
import websockets
import json
import os
import hashlib
import time
from pathlib import Path
import psutil
import yara
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Global variables
connected_clients = set()
scan_running = False
monitoring_running = False
scan_start_time = 0
total_files = 0
scanned_files = 0

# YARA rules for threat detection
yara_rules = """
rule suspicious_python {
    meta:
        description = "Detects suspicious Python code patterns"
    strings:
        $exec = "exec("
        $eval = "eval("
        $system = "system("
        $subprocess = "subprocess."
        $os_system = "os.system("
    condition:
        any of them
}

rule suspicious_file_operations {
    meta:
        description = "Detects suspicious file operations"
    strings:
        $write_binary = "wb"
        $write_text = "w"
        $append = "a"
        $read_binary = "rb"
    condition:
        any of them
}
"""

class FileEventHandler(FileSystemEventHandler):
    def __init__(self, websocket):
        self.websocket = websocket

    def on_created(self, event):
        if not event.is_directory:
            asyncio.run(self.send_monitoring_update(event.src_path, "created"))

    def on_modified(self, event):
        if not event.is_directory:
            asyncio.run(self.send_monitoring_update(event.src_path, "modified"))

    def on_deleted(self, event):
        if not event.is_directory:
            asyncio.run(self.send_monitoring_update(event.src_path, "deleted"))

    async def send_monitoring_update(self, file_path, status):
        try:
            await self.websocket.send(json.dumps({
                "type": "monitoring_update",
                "file": file_path,
                "status": status,
                "details": f"File {status}"
            }))
        except:
            pass

async def scan_file(file_path, websocket):
    global scanned_files
    try:
        # Calculate file hash
        with open(file_path, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()

        # Check file type
        file_ext = os.path.splitext(file_path)[1].lower()
        is_python_file = file_ext == '.py'

        # Check for threats using YARA rules
        rules = yara.compile(source=yara_rules)
        matches = rules.match(file_path)

        if matches:
            await websocket.send(json.dumps({
                "type": "threat_found",
                "file": file_path,
                "details": f"Potential threat detected: {matches[0].rule}"
            }))
        else:
            await websocket.send(json.dumps({
                "type": "file_safe",
                "file": file_path,
                "details": "No threats detected"
            }))

        scanned_files += 1
        progress = (scanned_files / total_files) * 100 if total_files > 0 else 0

        await websocket.send(json.dumps({
            "type": "file_scanned",
            "file": file_path,
            "progress": progress,
            "speed": "0.5"  # Placeholder for actual speed calculation
        }))

    except Exception as e:
        await websocket.send(json.dumps({
            "type": "warning_found",
            "file": file_path,
            "details": f"Error scanning file: {str(e)}"
        }))

async def scan_directory(directory, websocket, scan_options):
    global total_files, scanned_files
    total_files = 0
    scanned_files = 0

    # Count total files first
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            if should_scan_file(file_path, scan_options):
                total_files += 1

    # Perform actual scan
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            if should_scan_file(file_path, scan_options):
                await scan_file(file_path, websocket)

def should_scan_file(file_path, scan_options):
    if not scan_options['scanSystem'] and not file_path.startswith(os.path.expanduser('~')):
        return False

    if scan_options['scanPython'] and not file_path.endswith('.py'):
        return False

    if scan_options['scanRemovable'] and not any(drive.mountpoint in file_path for drive in psutil.disk_partitions() if 'removable' in drive.opts):
        return False

    return True

async def handle_client(websocket, path):
    global scan_running, monitoring_running
    connected_clients.add(websocket)
    observer = None

    try:
        async for message in websocket:
            data = json.loads(message)

            if data['type'] == 'start_scan':
                if not scan_running:
                    scan_running = True
                    scan_options = data['options']
                    await scan_directory(os.path.expanduser('~'), websocket, scan_options)
                    await websocket.send(json.dumps({
                        "type": "scan_complete",
                        "message": "Scan completed successfully"
                    }))
                    scan_running = False

            elif data['type'] == 'stop_scan':
                scan_running = False

            elif data['type'] == 'start_monitoring':
                if not monitoring_running:
                    monitoring_running = True
                    event_handler = FileEventHandler(websocket)
                    observer = Observer()
                    observer.schedule(event_handler, os.path.expanduser('~'), recursive=True)
                    observer.start()

            elif data['type'] == 'stop_monitoring':
                monitoring_running = False
                if observer:
                    observer.stop()
                    observer.join()

    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.remove(websocket)
        if observer:
            observer.stop()
            observer.join()

async def main():
    server = await websockets.serve(handle_client, "localhost", 8080)
    print("Scan server started on ws://localhost:8080")
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main()) 