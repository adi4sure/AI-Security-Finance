from fastapi import FastAPI, HTTPException, Depends, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer
from typing import List, Optional
import uvicorn
from datetime import datetime
import os
from dotenv import load_dotenv
from pydantic import BaseModel
import json

# Load environment variables
load_dotenv()

app = FastAPI(
    title="System Security Dashboard API",
    description="Backend API for System Security Dashboard",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for budgets (replace with database in production)
budgets = []

# WebSocket connections
active_connections = set()

# Budget models
class Budget(BaseModel):
    name: str
    amount: float
    alertThreshold: int
    spent: float = 0

class BudgetUpdate(BaseModel):
    name: str
    spent: float

# WebSocket endpoint for real-time updates
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.add(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Handle incoming WebSocket messages if needed
    except Exception as e:
        print(f"WebSocket error: {e}")
    finally:
        active_connections.remove(websocket)

# Broadcast budget updates to all connected clients
async def broadcast_budget_update():
    for connection in active_connections:
        try:
            await connection.send_json({
                "type": "budget_update",
                "budgets": budgets
            })
        except Exception as e:
            print(f"Error broadcasting update: {e}")

# Basic health check endpoint
@app.get("/")
async def root():
    return {"message": "System Security Dashboard API is running"}

# Budget endpoints
@app.get("/api/budgets")
async def get_budgets():
    return {"budgets": budgets}

@app.post("/api/budgets")
async def create_budget(budget: Budget):
    budgets.append(budget.dict())
    await broadcast_budget_update()
    return {"message": "Budget created successfully", "budget": budget}

@app.put("/api/budgets/{budget_name}")
async def update_budget(budget_name: str, update: BudgetUpdate):
    for budget in budgets:
        if budget["name"] == budget_name:
            budget["spent"] = update.spent
            await broadcast_budget_update()
            return {"message": "Budget updated successfully", "budget": budget}
    raise HTTPException(status_code=404, detail="Budget not found")

# Security scan endpoint
@app.get("/api/scan")
async def perform_scan():
    try:
        # TODO: Implement actual scanning logic
        return {
            "status": "success",
            "message": "System scan completed",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Security alerts endpoint
@app.get("/api/alerts")
async def get_alerts():
    try:
        # TODO: Implement actual alerts retrieval logic
        return {
            "status": "success",
            "alerts": [],
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# System settings endpoint
@app.get("/api/settings")
async def get_settings():
    try:
        # TODO: Implement settings retrieval logic
        return {
            "status": "success",
            "settings": {},
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True) 