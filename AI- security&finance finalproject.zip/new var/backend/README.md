# System Security Dashboard Backend

This is the backend API for the System Security Dashboard, built with FastAPI.

## Setup

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure environment variables:
- Copy `.env.example` to `.env`
- Update the values in `.env` as needed

## Running the Server

To start the development server:
```bash
python main.py
```

The server will start at `http://localhost:8000`

## API Documentation

Once the server is running, you can access:
- Swagger UI documentation: `http://localhost:8000/docs`
- ReDoc documentation: `http://localhost:8000/redoc`

## API Endpoints

- `GET /` - Health check
- `GET /api/scan` - Perform system scan
- `GET /api/alerts` - Get security alerts
- `GET /api/settings` - Get system settings

## Development

- The server runs in development mode with auto-reload enabled
- All endpoints are CORS-enabled for development
- Error handling is implemented for all endpoints 