import requests

url = "https://www.virustotal.com/api/v3/files"

headers = {
    "accept": "application/json",
    "content-type": "multipart/form-data"
}

response = requests.post(url, headers=headers)

print(response.text)