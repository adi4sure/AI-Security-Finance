document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const errorMessage = document.getElementById('errorMessage');

    // Check if user is already logged in
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.isLoggedIn) {
        window.location.href = 'dashboard.html';
        return;
    }

    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            // In a real application, this would be an API call to your backend
            if (username === 'admin' && password === 'admin123') {
                // Store user session
                localStorage.setItem('user', JSON.stringify({
                    username: username,
                    isLoggedIn: true
                }));
                
                // Redirect to dashboard
                window.location.href = 'dashboard.html';
            } else {
                errorMessage.textContent = 'Invalid username or password';
            }
        } catch (error) {
            errorMessage.textContent = 'An error occurred. Please try again.';
            console.error('Login error:', error);
        }
    });
});

// Add logout functionality
function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'landing.html';
}

// Check if user is already logged in
document.addEventListener('DOMContentLoaded', function() {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        window.location.href = 'dashboard.html';
    }
}); 