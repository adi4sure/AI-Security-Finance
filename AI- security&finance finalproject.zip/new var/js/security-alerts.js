document.addEventListener('DOMContentLoaded', () => {
    // Check authentication
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || !user.isLoggedIn) {
        window.location.href = 'index.html';
        return;
    }

    // Update welcome message
    document.getElementById('welcomeMessage').textContent = `Welcome, ${user.username}`;

    // Initialize security alerts
    loadSecurityAlerts();
    setupEventListeners();
    setupNavigation();
});

function setupEventListeners() {
    // Setup logout
    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    });

    // Setup filters
    document.getElementById('alertSeverity').addEventListener('change', loadSecurityAlerts);
    document.getElementById('alertStatus').addEventListener('change', loadSecurityAlerts);
    document.getElementById('alertDate').addEventListener('change', loadSecurityAlerts);
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        if (link.id !== 'logoutBtn') {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                if (href) {
                    window.location.href = href;
                }
            });
        }
        if (link.getAttribute('href') === '#logout') {
            e.preventDefault();
            logout();
        }
    });
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'landing.html';
}

function loadSecurityAlerts() {
    const severity = document.getElementById('alertSeverity').value;
    const status = document.getElementById('alertStatus').value;
    const date = document.getElementById('alertDate').value;

    const alerts = getFilteredAlerts(severity, status, date);
    updateAlertSummary(alerts);
    displayAlerts(alerts);
}

function getFilteredAlerts(severity, status, date) {
    const allAlerts = getSecurityAlerts();
    return allAlerts.filter(alert => {
        const matchesSeverity = severity === 'all' || alert.severity === severity;
        const matchesStatus = status === 'all' || alert.status === status;
        const matchesDate = !date || alert.date === date;
        return matchesSeverity && matchesStatus && matchesDate;
    });
}

function updateAlertSummary(alerts) {
    const activeAlerts = alerts.filter(a => a.status === 'active').length;
    const criticalIncidents = alerts.filter(a => a.severity === 'critical').length;
    const resolvedToday = alerts.filter(a => a.status === 'resolved' && isToday(a.date)).length;

    document.getElementById('activeAlertsCount').textContent = activeAlerts;
    document.getElementById('criticalIncidents').textContent = criticalIncidents;
    document.getElementById('resolvedToday').textContent = resolvedToday;
}

function displayAlerts(alerts) {
    const alertsList = document.getElementById('alertsList');
    alertsList.innerHTML = alerts.map(alert => `
        <div class="alert-item ${alert.severity}" onclick="showAlertDetails('${alert.id}')">
            <div class="alert-header">
                <span class="alert-title">${alert.title}</span>
                <span class="alert-severity">${alert.severity}</span>
            </div>
            <div class="alert-info">
                <span class="alert-time">${formatTime(alert.timestamp)}</span>
                <span class="alert-status">${alert.status}</span>
            </div>
            <p class="alert-description">${alert.description}</p>
        </div>
    `).join('') || '<p class="no-alerts">No alerts found</p>';
}

function showAlertDetails(alertId) {
    const alert = getSecurityAlerts().find(a => a.id === alertId);
    if (!alert) return;

    const detailsContent = document.querySelector('.details-content');
    detailsContent.innerHTML = `
        <div class="incident-header">
            <h4>${alert.title}</h4>
            <span class="severity-badge ${alert.severity}">${alert.severity}</span>
        </div>
        <div class="incident-info">
            <p><strong>Status:</strong> ${alert.status}</p>
            <p><strong>Time:</strong> ${formatTime(alert.timestamp)}</p>
            <p><strong>Source:</strong> ${alert.source}</p>
        </div>
        <div class="incident-description">
            <h5>Description</h5>
            <p>${alert.description}</p>
        </div>
        <div class="incident-actions">
            <button class="action-btn" onclick="updateAlertStatus('${alert.id}', 'investigating')">
                <i class="fas fa-search"></i> Investigate
            </button>
            <button class="action-btn" onclick="updateAlertStatus('${alert.id}', 'resolved')">
                <i class="fas fa-check"></i> Resolve
            </button>
        </div>
    `;
}

function updateAlertStatus(alertId, newStatus) {
    const alerts = getSecurityAlerts();
    const alertIndex = alerts.findIndex(a => a.id === alertId);
    if (alertIndex !== -1) {
        alerts[alertIndex].status = newStatus;
        localStorage.setItem('securityAlerts', JSON.stringify(alerts));
        loadSecurityAlerts();
    }
}

function getSecurityAlerts() {
    const savedAlerts = localStorage.getItem('securityAlerts');
    if (savedAlerts) {
        return JSON.parse(savedAlerts);
    }
    
    // Return demo data if no saved alerts exist
    return [
        {
            id: '1',
            title: 'Suspicious Login Attempt',
            description: 'Multiple failed login attempts detected from unknown IP address',
            severity: 'high',
            status: 'active',
            source: 'Authentication System',
            timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            date: new Date().toISOString().split('T')[0]
        },
        {
            id: '2',
            title: 'Unusual Data Access Pattern',
            description: 'Large amount of data accessed in short time period',
            severity: 'medium',
            status: 'investigating',
            source: 'Data Access Monitor',
            timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
            date: new Date().toISOString().split('T')[0]
        },
        {
            id: '3',
            title: 'System Vulnerability Detected',
            description: 'Critical security patch required for system components',
            severity: 'critical',
            status: 'active',
            source: 'Vulnerability Scanner',
            timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
            date: new Date().toISOString().split('T')[0]
        }
    ];
}

function formatTime(timestamp) {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    }).format(date);
}

function isToday(dateString) {
    const today = new Date().toISOString().split('T')[0];
    return dateString === today;
}

// Refresh alerts periodically
setInterval(loadSecurityAlerts, 30000); // Update every 30 seconds 