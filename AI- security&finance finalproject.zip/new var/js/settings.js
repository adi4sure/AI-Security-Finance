// settings.js
document.addEventListener('DOMContentLoaded', function() {
    // Initialize settings from localStorage or use defaults
    const settings = {
        twoFactorAuth: 'enabled',
        passwordChangeInterval: 90,
        emailNotifications: 'enabled',
        pushNotifications: 'enabled',
        alertThreshold: 80,
        currency: 'USD',
        taxRate: 20,
        financialReports: 'monthly'
    };

    // Load saved settings if they exist
    loadSettings();

    // Form elements
    const saveBtn = document.getElementById('saveSettingsBtn');
    const cancelBtn = document.querySelector('.btn-outline');
    const twoFactorAuth = document.getElementById('twoFactorAuth');
    const passwordChange = document.getElementById('passwordChange');
    const emailNotifications = document.getElementById('emailNotifications');
    const pushNotifications = document.getElementById('pushNotifications');
    const alertThreshold = document.getElementById('alertThreshold');
    const currency = document.getElementById('currency');
    const taxRate = document.getElementById('taxRate');
    const financialReports = document.getElementById('financialReports');
    const loginHistoryBtn = document.querySelector('[for="loginHistory"] + button');

    // Event listeners
    saveBtn.addEventListener('click', saveSettings);
    cancelBtn.addEventListener('click', resetForm);
    loginHistoryBtn.addEventListener('click', showLoginHistory);

    // Input validation
    passwordChange.addEventListener('change', validatePasswordInterval);
    alertThreshold.addEventListener('change', validateAlertThreshold);
    taxRate.addEventListener('change', validateTaxRate);

    // Load settings into form
    function loadSettings() {
        const savedSettings = JSON.parse(localStorage.getItem('dashboardSettings'));
        
        if (savedSettings) {
            // Update our settings object with saved values
            Object.assign(settings, savedSettings);
            
            // Update form fields
            twoFactorAuth.value = settings.twoFactorAuth;
            passwordChange.value = settings.passwordChangeInterval;
            emailNotifications.value = settings.emailNotifications;
            pushNotifications.value = settings.pushNotifications;
            alertThreshold.value = settings.alertThreshold;
            currency.value = settings.currency;
            taxRate.value = settings.taxRate;
            financialReports.value = settings.financialReports;
        }
    }

    // Save settings to localStorage
    function saveSettings() {
        // Update settings object with current form values
        settings.twoFactorAuth = twoFactorAuth.value;
        settings.passwordChangeInterval = parseInt(passwordChange.value);
        settings.emailNotifications = emailNotifications.value;
        settings.pushNotifications = pushNotifications.value;
        settings.alertThreshold = parseInt(alertThreshold.value);
        settings.currency = currency.value;
        settings.taxRate = parseInt(taxRate.value);
        settings.financialReports = financialReports.value;

        // Save to localStorage
        localStorage.setItem('dashboardSettings', JSON.stringify(settings));
        
        // Show success message
        showToast('Settings saved successfully!', 'success');
        
        // Log the saved settings (for debugging)
        console.log('Settings saved:', settings);
    }

    // Reset form to saved settings
    function resetForm() {
        loadSettings();
        showToast('Changes discarded', 'info');
    }

    // Show login history (mock function)
    function showLoginHistory() {
        // In a real app, this would fetch data from a server
        const mockHistory = [
            { date: '2023-11-15 09:30', location: 'New York, US', device: 'Chrome on Windows' },
            { date: '2023-11-14 18:45', location: 'London, UK', device: 'Safari on iPhone' },
            { date: '2023-11-13 07:12', location: 'Tokyo, JP', device: 'Firefox on Mac' }
        ];

        const historyHtml = mockHistory.map(entry => `
            <div class="history-entry">
                <div><strong>${entry.date}</strong></div>
                <div>${entry.location}</div>
                <div>${entry.device}</div>
            </div>
        `).join('');

        // Create a modal to display the history
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3><i class="fas fa-history"></i> Login History</h3>
                    <button class="close-modal">&times;</button>
                </div>
                <div class="modal-body">
                    ${historyHtml}
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add styles for the modal
        const style = document.createElement('style');
        style.textContent = `
            .modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: rgba(0,0,0,0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 1000;
            }
            .modal-content {
                background-color: white;
                border-radius: var(--border-radius);
                width: 90%;
                max-width: 600px;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            }
            .modal-header {
                padding: 1rem;
                border-bottom: 1px solid #eee;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .modal-header h3 {
                margin: 0;
                display: flex;
                align-items: center;
                gap: 0.5rem;
            }
            .modal-body {
                padding: 1rem;
            }
            .history-entry {
                padding: 0.75rem 0;
                border-bottom: 1px solid #f0f0f0;
            }
            .history-entry:last-child {
                border-bottom: none;
            }
            .close-modal {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: var(--gray-color);
            }
        `;
        document.head.appendChild(style);

        // Close modal functionality
        modal.querySelector('.close-modal').addEventListener('click', () => {
            document.body.removeChild(modal);
            document.head.removeChild(style);
        });
    }

    // Validation functions
    function validatePasswordInterval() {
        const value = parseInt(passwordChange.value);
        if (value < 1) {
            passwordChange.value = 1;
            showToast('Password change interval must be at least 1 day', 'warning');
        } else if (value > 365) {
            passwordChange.value = 365;
            showToast('Password change interval cannot exceed 365 days', 'warning');
        }
    }

    function validateAlertThreshold() {
        const value = parseInt(alertThreshold.value);
        if (value < 0) {
            alertThreshold.value = 0;
            showToast('Alert threshold cannot be negative', 'warning');
        } else if (value > 100) {
            alertThreshold.value = 100;
            showToast('Alert threshold cannot exceed 100%', 'warning');
        }
    }

    function validateTaxRate() {
        const value = parseInt(taxRate.value);
        if (value < 0) {
            taxRate.value = 0;
            showToast('Tax rate cannot be negative', 'warning');
        } else if (value > 100) {
            taxRate.value = 100;
            showToast('Tax rate cannot exceed 100%', 'warning');
        }
    }

    // Show toast notifications
    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        // Add toast styles if they don't exist
        if (!document.getElementById('toast-styles')) {
            const style = document.createElement('style');
            style.id = 'toast-styles';
            style.textContent = `
                .toast {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    padding: 12px 20px;
                    border-radius: var(--border-radius);
                    color: white;
                    box-shadow: var(--box-shadow);
                    z-index: 1000;
                    animation: slideIn 0.3s, fadeOut 0.5s 2.5s;
                }
                .toast-success {
                    background-color: var(--success-color);
                }
                .toast-warning {
                    background-color: var(--warning-color);
                }
                .toast-info {
                    background-color: var(--primary-color);
                }
                @keyframes slideIn {
                    from { transform: translateX(100%); }
                    to { transform: translateX(0); }
                }
                @keyframes fadeOut {
                    from { opacity: 1; }
                    to { opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(toast);
        
        // Remove toast after animation
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    // Initialize with default values if no settings exist
    if (!localStorage.getItem('dashboardSettings')) {
        saveSettings();
    }
});