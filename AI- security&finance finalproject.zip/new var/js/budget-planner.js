// Budget Planner JavaScript - Enhanced Version
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the budget planner with enhanced features
    initBudgetPlanner();
});

// Global variables with additional properties
let budgets = [];
const STORAGE_KEY = 'budget_planner_data_v2'; // Updated storage key for new version
const DEFAULT_CATEGORIES = ['Food', 'Housing', 'Transportation', 'Entertainment', 'Utilities', 'Healthcare', 'Savings', 'Other'];
const COLOR_PALETTE = ['#4361ee', '#3a0ca3', '#7209b7', '#f72585', '#4cc9f0', '#4895ef', '#b5179e', '#560bad'];

// Chart instances
let budgetDistributionChart;
let spendingProgressChart;
let monthlyTrendsChart;
let categorySpendingChart;

// Initialize the budget planner with enhanced features
function initBudgetPlanner() {
    // Set current month and year
    const currentDate = new Date();
    const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
    const currentYear = currentDate.getFullYear();
    document.getElementById('current-month-year').textContent = `${currentMonth} ${currentYear}`;

    // Load existing budgets
    loadBudgets();

    // Initialize UI components
    initCategoryAutocomplete();
    initColorPickers();
    initDatePickers();

    // Event listeners with enhanced functionality
    setupEventListeners();

    // Initialize charts with better defaults
    initCharts();

    // Setup real-time updates if needed
    setupRealTimeUpdates();
}

// Enhanced event listeners setup
function setupEventListeners() {
    // Budget form handling
    document.getElementById('add-budget-btn').addEventListener('click', showAddBudgetModal);
    document.getElementById('close-modal').addEventListener('click', hideAddBudgetModal);
    document.getElementById('budget-form').addEventListener('submit', handleBudgetSubmit);
    
    // Budget actions
    document.getElementById('sort-budgets').addEventListener('click', handleSortBudgets);
    document.getElementById('filter-alerts').addEventListener('click', handleFilterAlerts);
    document.getElementById('refresh-data').addEventListener('click', refreshAllData);
    
    // Modal interactions
    document.getElementById('budget-modal').addEventListener('click', function(e) {
        if (e.target === this) hideAddBudgetModal();
    });
    
    // Quick add buttons
    document.querySelectorAll('.quick-add-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const amount = parseFloat(this.dataset.amount);
            if (!isNaN(amount)) {
                document.getElementById('budget-amount').value = amount;
                document.getElementById('budget-amount').dispatchEvent(new Event('input'));
            }
        });
    });
}

// Enhanced load budgets function
function loadBudgets() {
    try {
        const storedData = localStorage.getItem(STORAGE_KEY);
        if (storedData) {
            budgets = JSON.parse(storedData);
            
            // Migrate old data if needed
            if (!budgets[0]?.color) {
                budgets = budgets.map((budget, index) => ({
                    ...budget,
                    color: COLOR_PALETTE[index % COLOR_PALETTE.length],
                    createdAt: budget.createdAt || new Date().toISOString()
                }));
                saveBudgets();
            }
        } else {
            // Create sample data with enhanced properties
            budgets = [
                {
                    id: generateId(),
                    name: "Groceries",
                    amount: 600,
                    spent: 450,
                    alertThreshold: 80,
                    color: '#4cc9f0',
                    icon: 'shopping-cart',
                    createdAt: new Date().toISOString(),
                    transactions: []
                },
                {
                    id: generateId(),
                    name: "Utilities",
                    amount: 250,
                    spent: 220,
                    alertThreshold: 90,
                    color: '#4895ef',
                    icon: 'bolt',
                    createdAt: new Date().toISOString(),
                    transactions: []
                },
                {
                    id: generateId(),
                    name: "Entertainment",
                    amount: 350,
                    spent: 180,
                    alertThreshold: 75,
                    color: '#f72585',
                    icon: 'film',
                    createdAt: new Date().toISOString(),
                    transactions: []
                }
            ];
            saveBudgets();
        }
        updateUI();
    } catch (error) {
        console.error('Error loading budgets:', error);
        showAlert('Error loading budget data. Please try again.', 'danger');
        // Attempt to recover with empty array
        budgets = [];
        saveBudgets();
    }
}

// Enhanced save budgets function
function saveBudgets() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(budgets));
        // Optional: Sync with backend if available
        if (typeof syncWithBackend === 'function') {
            syncWithBackend();
        }
    } catch (error) {
        console.error('Error saving budgets:', error);
        showAlert('Error saving budget data. Storage might be full.', 'danger');
    }
}

// Enhanced UI update function
function updateUI() {
    updateSummaryCards();
    updateBudgetList();
    updateAlertsList();
    updateCharts();
    updateQuickActions();
}

// Enhanced summary cards update
function updateSummaryCards() {
    const totalBudget = budgets.reduce((sum, budget) => sum + budget.amount, 0);
    const totalSpent = budgets.reduce((sum, budget) => sum + budget.spent, 0);
    const remaining = totalBudget - totalSpent;
    const percentageSpent = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

    // Update cards with animation
    animateValue('total-budget', 0, totalBudget, 1000);
    animateValue('total-spent', 0, totalSpent, 1000);
    animateValue('remaining-budget', 0, remaining, 1000);

    // Update progress circle
    const progressCircle = document.getElementById('spending-progress-circle');
    const circumference = 2 * Math.PI * 40;
    const offset = circumference - (percentageSpent / 100) * circumference;
    
    progressCircle.style.strokeDashoffset = offset;
    progressCircle.style.stroke = getProgressColor(percentageSpent);
    
    // Update percentage display
    document.getElementById('spending-percentage').textContent = `${percentageSpent.toFixed(1)}%`;
}

// Animate value changes
function animateValue(id, start, end, duration) {
    const element = document.getElementById(id);
    const range = end - start;
    const startTime = performance.now();
    
    function updateValue(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const value = start + (progress * range);
        
        element.textContent = formatCurrency(value);
        
        if (progress < 1) {
            requestAnimationFrame(updateValue);
        }
    }
    
    requestAnimationFrame(updateValue);
}

// Get progress color based on percentage
function getProgressColor(percentage) {
    if (percentage >= 100) return '#f72585';
    if (percentage >= 80) return '#f8961e';
    return '#4cc9f0';
}

// Enhanced budget list update
function updateBudgetList() {
    const container = document.getElementById('budgets-container');
    container.innerHTML = '';

    if (budgets.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-folder-open fa-3x"></i>
                <h3>No Budgets Yet</h3>
                <p>Create your first budget to start tracking your expenses</p>
                <button class="btn btn-primary" id="add-first-budget">
                    <i class="fas fa-plus"></i> Add Budget
                </button>
            </div>
        `;
        
        document.getElementById('add-first-budget')?.addEventListener('click', showAddBudgetModal);
        return;
    }

    budgets.forEach(budget => {
        const percentage = (budget.spent / budget.amount) * 100;
        const budgetElement = document.createElement('div');
        budgetElement.className = `budget-card ${percentage >= 100 ? 'over-limit' : percentage >= budget.alertThreshold ? 'near-limit' : ''}`;
        budgetElement.innerHTML = `
            <div class="budget-header" style="border-left-color: ${budget.color}">
                <div class="budget-icon" style="background-color: ${budget.color}">
                    <i class="fas fa-${budget.icon || 'folder'}"></i>
                </div>
                <div class="budget-info">
                    <h3>${budget.name}</h3>
                    <small>Created ${formatDate(budget.createdAt)}</small>
                </div>
                <div class="budget-actions">
                    <button class="btn-icon edit-btn" data-id="${budget.id}" title="Edit Budget">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn-icon delete-btn" data-id="${budget.id}" title="Delete Budget">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            <div class="budget-progress">
                <div class="progress-labels">
                    <span>${formatCurrency(budget.spent)}</span>
                    <span>${formatCurrency(budget.amount)}</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${Math.min(percentage, 100)}%; background-color: ${budget.color}"></div>
                </div>
                <div class="progress-percentage" style="color: ${budget.color}">
                    ${percentage.toFixed(1)}%
                </div>
            </div>
            <div class="budget-footer">
                <button class="btn btn-sm btn-add-expense" data-id="${budget.id}">
                    <i class="fas fa-plus"></i> Add Expense
                </button>
                <button class="btn btn-sm btn-view-details" data-id="${budget.id}">
                    <i class="fas fa-chart-pie"></i> Details
                </button>
            </div>
        `;
        container.appendChild(budgetElement);
    });

    // Add event listeners to all action buttons
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const budget = budgets.find(b => b.id === btn.dataset.id);
            if (budget) editBudget(budget);
        });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const budget = budgets.find(b => b.id === btn.dataset.id);
            if (budget) deleteBudget(budget);
        });
    });

    document.querySelectorAll('.btn-add-expense').forEach(btn => {
        btn.addEventListener('click', () => {
            const budget = budgets.find(b => b.id === btn.dataset.id);
            if (budget) showAddExpenseModal(budget);
        });
    });
}






// Replace your existing handleBudgetSubmit() function with this:
function handleBudgetSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const isEdit = form.dataset.editId;
    
    // Get form values directly from elements
    const name = document.getElementById('budget-name').value.trim();
    const amountInput = document.getElementById('budget-amount').value;
    const amount = parseFloat(amountInput);
    const threshold = parseInt(document.getElementById('alert-threshold').value) || 80;
    const icon = document.getElementById('budget-icon').value;
    
    // Validate inputs
    if (!name) {
        showAlert('Please enter a budget name', 'warning');
        return;
    }
    
    if (isNaN(amount) || amount <= 0) {
        showAlert('Please enter a valid budget amount', 'warning');
        return;
    }
    
    // Prepare budget data
    const budgetData = {
        id: isEdit || generateId(),
        name: name,
        amount: amount,
        spent: isEdit ? budgets.find(b => b.id === isEdit)?.spent || 0 : 0,
        alertThreshold: threshold,
        color: isEdit ? budgets.find(b => b.id === isEdit)?.color : COLOR_PALETTE[budgets.length % COLOR_PALETTE.length],
        icon: icon,
        createdAt: isEdit ? budgets.find(b => b.id === isEdit)?.createdAt : new Date().toISOString(),
        transactions: isEdit ? budgets.find(b => b.id === isEdit)?.transactions || [] : []
    };
    
    if (isEdit) {
        // Update existing budget
        const index = budgets.findIndex(b => b.id === isEdit);
        if (index !== -1) {
            budgets[index] = budgetData;
            showAlert('Budget updated successfully!', 'success');
        }
    } else {
        // Add new budget - check for duplicate name
        if (budgets.some(b => b.name.toLowerCase() === name.toLowerCase())) {
            showAlert('A budget with this name already exists', 'warning');
            return;
        }
        
        budgets.push(budgetData);
        showAlert('Budget added successfully!', 'success');
    }
    
    // Save budgets with error handling
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(budgets));
        updateUI();
        hideAddBudgetModal();
    } catch (error) {
        console.error('Error saving budgets:', error);
        if (error.name === 'QuotaExceededError') {
            showAlert('Storage is full. Please clear some space.', 'danger');
        } else {
            showAlert('Error saving budget data. Please try again.', 'danger');
        }
    }
}

// Replace your existing saveBudgets() function with this simpler version:
function saveBudgets() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(budgets));
        return true;
    } catch (error) {
        console.error('Error saving budgets:', error);
        if (error.name === 'QuotaExceededError') {
            showAlert('Storage is full. Please clear some space.', 'danger');
        } else {
            showAlert('Error saving budget data. Please try again.', 'danger');
        }
        return false;
    }
}









// Enhanced add budget modal
function showAddBudgetModal(budgetToEdit = null) {
    const modal = document.getElementById('budget-modal');
    const form = document.getElementById('budget-form');
    
    if (budgetToEdit) {
        // Editing existing budget
        document.getElementById('modal-title').textContent = 'Edit Budget';
        document.getElementById('submit-budget').textContent = 'Update Budget';
        form.dataset.editId = budgetToEdit.id;
        
        // Fill form with existing data
        document.getElementById('budget-name').value = budgetToEdit.name;
        document.getElementById('budget-amount').value = budgetToEdit.amount;
        document.getElementById('alert-threshold').value = budgetToEdit.alertThreshold;
        document.getElementById('budget-color').value = budgetToEdit.color;
        document.getElementById('budget-icon').value = budgetToEdit.icon || 'folder';
    } else {
        // Adding new budget
        document.getElementById('modal-title').textContent = 'Add New Budget';
        document.getElementById('submit-budget').textContent = 'Add Budget';
        form.removeAttribute('data-edit-id');
        
        // Reset form
        form.reset();
        
        // Set default color
        const nextColor = COLOR_PALETTE[budgets.length % COLOR_PALETTE.length];
        document.getElementById('budget-color').value = nextColor;
    }
    
    // Show modal with animation
    modal.classList.add('show');
    document.body.classList.add('modal-open');
    document.getElementById('budget-name').focus();
}

function hideAddBudgetModal() {
    const modal = document.getElementById('budget-modal');
    modal.classList.remove('show');
    document.body.classList.remove('modal-open');
    
    // Reset form after animation completes
    setTimeout(() => {
        document.getElementById('budget-form').reset();
    }, 300);
}

// Enhanced budget form handling
function handleBudgetSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const isEdit = form.dataset.editId;
    const formData = new FormData(form);
    
    const budgetData = {
        id: isEdit || generateId(),
        name: formData.get('name'),
        amount: parseFloat(formData.get('amount')),
        spent: isEdit ? budgets.find(b => b.id === isEdit)?.spent || 0 : 0,
        alertThreshold: parseInt(formData.get('alertThreshold')),
        color: formData.get('color'),
        icon: formData.get('icon'),
        createdAt: isEdit ? budgets.find(b => b.id === isEdit)?.createdAt : new Date().toISOString(),
        transactions: isEdit ? budgets.find(b => b.id === isEdit)?.transactions || [] : []
    };
    
    // Validate data
    if (!budgetData.name || !budgetData.amount || isNaN(budgetData.amount)) {
        showAlert('Please fill all required fields with valid data', 'warning');
        return;
    }
    
    if (isEdit) {
        // Update existing budget
        const index = budgets.findIndex(b => b.id === isEdit);
        if (index !== -1) {
            budgets[index] = budgetData;
            showAlert('Budget updated successfully!', 'success');
        }
    } else {
        // Add new budget
        // Check for duplicate name
        if (budgets.some(b => b.name.toLowerCase() === budgetData.name.toLowerCase())) {
            showAlert('A budget with this name already exists', 'warning');
            return;
        }
        
        budgets.push(budgetData);
        showAlert('Budget added successfully!', 'success');
    }
    
    saveBudgets();
    updateUI();
    hideAddBudgetModal();
}

// Enhanced edit budget function
function editBudget(budget) {
    showAddBudgetModal(budget);
}

// Enhanced delete budget function
function deleteBudget(budget) {
    showConfirmDialog(
        `Delete ${budget.name} Budget?`,
        `Are you sure you want to delete the "${budget.name}" budget? All associated expenses will be lost.`,
        'Delete',
        'Cancel'
    ).then(() => {
        budgets = budgets.filter(b => b.id !== budget.id);
        saveBudgets();
        updateUI();
        showAlert('Budget deleted successfully', 'success');
    }).catch(() => {
        // User cancelled
    });
}

// Enhanced utility functions
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

function showAlert(message, type, duration = 3000) {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} show`;
    alert.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 
                         type === 'warning' ? 'fa-exclamation-triangle' : 
                         'fa-exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    
    document.getElementById('alerts-container').appendChild(alert);
    
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => alert.remove(), 300);
    }, duration);
}

function showConfirmDialog(title, message, confirmText, cancelText) {
    return new Promise((resolve, reject) => {
        const dialog = document.createElement('div');
        dialog.className = 'confirm-dialog';
        dialog.innerHTML = `
            <div class="dialog-content">
                <h3>${title}</h3>
                <p>${message}</p>
                <div class="dialog-actions">
                    <button class="btn btn-secondary" id="dialog-cancel">${cancelText}</button>
                    <button class="btn btn-danger" id="dialog-confirm">${confirmText}</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(dialog);
        
        document.getElementById('dialog-confirm').addEventListener('click', () => {
            dialog.remove();
            resolve();
        });
        
        document.getElementById('dialog-cancel').addEventListener('click', () => {
            dialog.remove();
            reject();
        });
    });
}

// Initialize UI components
function initCategoryAutocomplete() {
    const input = document.getElementById('budget-name');
    const datalist = document.createElement('datalist');
    datalist.id = 'category-suggestions';
    
    DEFAULT_CATEGORIES.forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        datalist.appendChild(option);
    });
    
    input.parentNode.insertBefore(datalist, input.nextSibling);
    input.setAttribute('list', 'category-suggestions');
}

function initColorPickers() {
    const colorInput = document.getElementById('budget-color');
    colorInput.addEventListener('input', function() {
        document.getElementById('color-preview').style.backgroundColor = this.value;
    });
    
    // Initialize color preview
    document.getElementById('color-preview').style.backgroundColor = colorInput.value;
}

function initDatePickers() {
    // Initialize any date pickers if needed
}

// Initialize charts with enhanced options
function initCharts() {
    // Budget Distribution Chart (Enhanced Doughnut)
    const budgetCtx = document.getElementById('budget-distribution-chart').getContext('2d');
    budgetDistributionChart = new Chart(budgetCtx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [],
                borderWidth: 0,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        usePointStyle: true,
                        padding: 16,
                        font: {
                            family: "'Segoe UI', sans-serif"
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${formatCurrency(value)} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true
            }
        }
    });

    // Update all charts initially
    updateCharts();
}

// Enhanced chart updates
function updateCharts() {
    updateBudgetDistributionChart();
    // Add updates for other charts as needed
}

function updateBudgetDistributionChart() {
    const labels = budgets.map(budget => budget.name);
    const data = budgets.map(budget => budget.amount);
    const backgroundColors = budgets.map(budget => budget.color);

    budgetDistributionChart.data.labels = labels;
    budgetDistributionChart.data.datasets[0].data = data;
    budgetDistributionChart.data.datasets[0].backgroundColor = backgroundColors;
    budgetDistributionChart.update();
}

// Setup real-time updates (example using setTimeout for demo)
function setupRealTimeUpdates() {
    // In a real app, this would use WebSockets or similar
    setInterval(() => {
        // Simulate occasional expense additions
        if (Math.random() > 0.7 && budgets.length > 0) {
            const randomBudget = budgets[Math.floor(Math.random() * budgets.length)];
            const amount = Math.floor(Math.random() * 50) + 10;
            
            randomBudget.spent += amount;
            randomBudget.transactions.push({
                id: generateId(),
                amount,
                date: new Date().toISOString(),
                description: `Random expense #${Math.floor(Math.random() * 1000)}`
            });
            
            saveBudgets();
            updateUI();
            
            // Show notification if threshold crossed
            const percentage = (randomBudget.spent / randomBudget.amount) * 100;
            if (percentage >= randomBudget.alertThreshold) {
                showAlert(`Budget alert: ${randomBudget.name} is at ${percentage.toFixed(1)}%`, 
                         percentage >= 100 ? 'danger' : 'warning');
            }
        }
    }, 10000); // Update every 10 seconds for demo
}

// Initialize the planner when DOM is loaded
document.addEventListener('DOMContentLoaded', initBudgetPlanner);