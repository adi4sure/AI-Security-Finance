document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) return;
    initializeExpenseTracker();
});

function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || !user.isLoggedIn) {
        window.location.href = 'index.html';
        return false;
    }
    document.getElementById('welcomeMessage').textContent = `Welcome, ${user.username}`;
    return true;
}

function initializeExpenseTracker() {
    loadExpenses();
    updateSummary();
    setupEventListeners();
    setupNavigation();
}

function setupEventListeners() {
    // Setup form submission
    document.getElementById('expenseForm').addEventListener('submit', handleExpenseSubmit);

    // Setup filters
    document.getElementById('filterCategory').addEventListener('change', loadExpenses);
    document.getElementById('filterMonth').addEventListener('change', loadExpenses);

    // Setup logout
    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    });

    // Setup navigation
    setupNavigation();
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        if (link.id !== 'logoutBtn') {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                if (href) {
                    window.location.href = href;
                }
            });
        }
        if (link.getAttribute('href') === '#logout') {
            e.preventDefault();
            logout();
        }
    });
}

function logout() {
    localStorage.removeItem('currentUser');
    window.location.href = 'landing.html';
}

function handleExpenseSubmit(e) {
    e.preventDefault();
    const expenses = getExpenses();
    expenses.push({
        id: Date.now(),
        name: document.getElementById('expenseName').value,
        amount: parseFloat(document.getElementById('expenseAmount').value),
        category: document.getElementById('expenseCategory').value,
        date: document.getElementById('expenseDate').value
    });
    localStorage.setItem('expenses', JSON.stringify(expenses));
    e.target.reset();
    loadExpenses();
    updateSummary();
}

function loadExpenses() {
    const expenses = getFilteredExpenses();
    document.getElementById('expenseList').innerHTML = expenses.map(expense => `
        <div class="expense-item">
            <h4>${expense.name}</h4>
            <p>${expense.category} - ${formatDate(expense.date)}</p>
            <div>${formatCurrency(expense.amount)}</div>
        </div>
    `).join('') || '<p>No expenses found</p>';
}

function getFilteredExpenses() {
    const expenses = getExpenses();
    const category = document.getElementById('filterCategory').value;
    const month = document.getElementById('filterMonth').value;
    return expenses.filter(expense => {
        return (category === 'all' || expense.category === category) &&
               (!month || expense.date.startsWith(month));
    });
}

function updateSummary() {
    const expenses = getExpenses();
    const total = expenses.reduce((sum, e) => sum + e.amount, 0);
    const budget = 5000;
    document.getElementById('totalExpenses').textContent = formatCurrency(total);
    document.getElementById('monthlyBudget').textContent = formatCurrency(budget);
    document.getElementById('remainingBudget').textContent = formatCurrency(budget - total);
}

function getExpenses() {
    return JSON.parse(localStorage.getItem('expenses')) || [];
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString();
} 