document.addEventListener('DOMContentLoaded', () => {
    // Theme switching functionality
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme') || 'light';
    body.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    themeToggle.addEventListener('click', () => {
        const currentTheme = body.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        body.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
    });

    function updateThemeIcon(theme) {
        const icon = themeToggle.querySelector('i');
        icon.className = theme === 'light' ? 'fas fa-sun' : 'fas fa-moon';
    }

    // Check if user is logged in
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        window.location.href = 'landing.html';
        return;
    }

    // Initialize dashboard
    initializeDashboard();
});

function initializeDashboard() {
    // System Scan Integration
    const startScanBtn = document.getElementById('startScanBtn');
    const stopScanBtn = document.getElementById('stopScanBtn');

    startScanBtn.addEventListener('click', () => {
        systemScan.startScan({
            scanSystem: true,
            scanPython: true,
            scanRemovable: true,
            scanDepth: 3
        });
        startScanBtn.disabled = true;
        stopScanBtn.disabled = false;
    });

    stopScanBtn.addEventListener('click', () => {
        systemScan.stopScan();
        startScanBtn.disabled = false;
        stopScanBtn.disabled = true;
    });

    // Check authentication
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || !user.isLoggedIn) {
        window.location.href = 'index.html';
        return;
    }

    // Update welcome message
    document.getElementById('welcomeMessage').textContent = `Welcome, ${user.username}`;

    // Initialize dashboard components
    initializeSecurityMetrics();
    initializeFinancialOverview();
    loadRecentActivity();
    setupEventListeners();

    // Setup logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Set username if available
    const username = localStorage.getItem('username');
    if (username) {
        const usernameElement = document.getElementById('username');
        if (usernameElement) {
            usernameElement.textContent = username;
        }
    }

    // Setup navigation links
    setupNavigation();

    // System metrics elements
    const cpuUsage = document.getElementById('cpuUsage');
    const memoryUsage = document.getElementById('memoryUsage');
    const storageUsage = document.getElementById('storageUsage');
    const cpuProgress = document.getElementById('cpuProgress');
    const memoryProgress = document.getElementById('memoryProgress');
    const storageProgress = document.getElementById('storageProgress');

    // Security status elements
    const securityStatus = document.getElementById('securityStatus');
    const alertStatus = document.getElementById('alertStatus');
    const performanceStatus = document.getElementById('performanceStatus');
    const alertCount = document.getElementById('alertCount');
    const notificationCount = document.getElementById('notificationCount');

    // Security overview elements
    const firewallStatus = document.getElementById('firewallStatus');
    const virusStatus = document.getElementById('virusStatus');
    const encryptionStatus = document.getElementById('encryptionStatus');

    // Activity list
    const activityList = document.getElementById('activityList');

    // Buttons
    const refreshStatus = document.getElementById('refreshStatus');
    const runSecurityCheck = document.getElementById('runSecurityCheck');
    const scanSystem = document.getElementById('scanSystem');
    const backupSystem = document.getElementById('backupSystem');
    const updateSystem = document.getElementById('updateSystem');
    const optimizeSystem = document.getElementById('optimizeSystem');

    // Get real system metrics from systemch.py
    async function getSystemMetrics() {
        try {
            const response = await fetch('http://localhost:5000/system_metrics');
            if (!response.ok) {
                throw new Error('Failed to fetch system metrics');
            }
            const data = await response.json();
            return {
                cpu: {
                    usage: data.cpu.usage,
                    temperature: data.cpu.temperature,
                    cores: data.cpu.cores,
                    frequency: data.cpu.frequency
                },
                memory: {
                    usage: data.memory.usage,
                    total: formatBytes(data.memory.total),
                    available: formatBytes(data.memory.available),
                    used: formatBytes(data.memory.used)
                },
                storage: {
                    usage: data.storage.usage,
                    total: formatBytes(data.storage.total),
                    available: formatBytes(data.storage.available),
                    used: formatBytes(data.storage.used)
                },
                network: {
                    sent: formatBytes(data.network.bytes_sent),
                    received: formatBytes(data.network.bytes_received)
                },
                processes: data.processes,
                timestamp: data.timestamp
            };
        } catch (error) {
            console.error('Error fetching system metrics:', error);
            return null;
        }
    }

    // Get real security status from Python backend
    async function getSecurityStatus() {
        try {
            const response = await fetch('http://localhost:5000/api/security/status');
            if (!response.ok) {
                throw new Error('Failed to fetch security status');
            }
            const data = await response.json();
            return {
                securityLevel: data.securityLevel,
                activeAlerts: data.activeAlerts,
                firewall: data.firewall,
                antivirus: data.antivirus,
                encryption: data.encryption,
                lastScan: data.lastScan,
                threatsDetected: data.threatsDetected
            };
        } catch (error) {
            console.error('Error fetching security status:', error);
            return null;
        }
    }

    // Get real-time system activities from Python backend
    async function getSystemActivities() {
        try {
            const response = await fetch('http://localhost:5000/api/system/activities');
            if (!response.ok) {
                throw new Error('Failed to fetch system activities');
            }
            const data = await response.json();
            return data.activities.map(activity => ({
                type: activity.type,
                title: activity.title,
                description: activity.description,
                timestamp: activity.timestamp,
                severity: activity.severity
            }));
        } catch (error) {
            console.error('Error fetching system activities:', error);
            return [];
        }
    }

    // Format bytes to human-readable format
    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Update system metrics with real data
    async function updateSystemMetrics() {
        const metrics = await getSystemMetrics();
        if (metrics) {
            // CPU Usage
            cpuUsage.textContent = `${metrics.cpu.usage}%`;
            cpuProgress.style.width = `${metrics.cpu.usage}%`;
            cpuProgress.className = `progress ${getProgressClass(metrics.cpu.usage)}`;

            // Memory Usage
            memoryUsage.textContent = `${metrics.memory.usage}%`;
            memoryProgress.style.width = `${metrics.memory.usage}%`;
            memoryProgress.className = `progress ${getProgressClass(metrics.memory.usage)}`;

            // Storage Usage
            storageUsage.textContent = `${metrics.storage.usage}%`;
            storageProgress.style.width = `${metrics.storage.usage}%`;
            storageProgress.className = `progress ${getProgressClass(metrics.storage.usage)}`;

            // Update performance status
            const avgPerformance = (metrics.cpu.usage + metrics.memory.usage + metrics.storage.usage) / 3;
            performanceStatus.textContent = `${Math.floor(100 - avgPerformance)}%`;

            // Update detailed metrics
            updateDetailedMetrics(metrics);

            // Add system activity
            addSystemActivity(metrics);
        }
    }

    // Update detailed system metrics
    function updateDetailedMetrics(metrics) {
        // Update CPU details
        document.getElementById('cpuCores').textContent = metrics.cpu.cores;
        document.getElementById('cpuFrequency').textContent = metrics.cpu.frequency ? `${metrics.cpu.frequency} MHz` : 'N/A';
        document.getElementById('cpuTemperature').textContent = metrics.cpu.temperature ? `${metrics.cpu.temperature}°C` : 'N/A';

        // Update Memory details
        document.getElementById('memoryTotal').textContent = metrics.memory.total;
        document.getElementById('memoryAvailable').textContent = metrics.memory.available;
        document.getElementById('memoryUsed').textContent = metrics.memory.used;

        // Update Storage details
        document.getElementById('storageTotal').textContent = metrics.storage.total;
        document.getElementById('storageAvailable').textContent = metrics.storage.available;
        document.getElementById('storageUsed').textContent = metrics.storage.used;

        // Update Network details
        document.getElementById('networkSent').textContent = metrics.network.sent;
        document.getElementById('networkReceived').textContent = metrics.network.received;

        // Update Process list
        const processList = document.getElementById('processList');
        processList.innerHTML = metrics.processes.map(process => 
            `<div class="process-item">${process}</div>`
        ).join('');
    }

    // Get progress bar class based on value
    function getProgressClass(value) {
        if (value < 50) return 'safe';
        if (value < 80) return 'warning';
        return 'danger';
    }

    // Update security status with real data
    async function updateSecurityStatus() {
        const status = await getSecurityStatus();
        if (status) {
            // Update security status
            securityStatus.textContent = `${status.securityLevel}%`;
            
            // Update alerts
            alertStatus.textContent = status.activeAlerts;
            alertCount.textContent = status.activeAlerts;
            notificationCount.textContent = status.activeAlerts;

            // Update security features
            firewallStatus.textContent = status.firewall ? 'Active' : 'Inactive';
            virusStatus.textContent = status.antivirus ? 'Enabled' : 'Disabled';
            encryptionStatus.textContent = status.encryption ? 'Enabled' : 'Disabled';

            // Update security indicators
            updateSecurityIndicators(status);
        }
    }

    // Update security indicators
    function updateSecurityIndicators(status) {
        const indicators = document.querySelectorAll('.security-indicator');
        indicators.forEach(indicator => {
            const type = indicator.dataset.type;
            const value = status[type];
            indicator.className = `security-indicator ${value ? 'active' : 'inactive'}`;
        });
    }

    // Update activity list with real data
    async function updateActivityList() {
        const activities = await getSystemActivities();
        activityList.innerHTML = '';
        
        activities.forEach(activity => {
            const activityItem = document.createElement('div');
            activityItem.className = `activity-item ${activity.severity || ''}`;
            
            activityItem.innerHTML = `
                <div class="activity-icon">
                    <i class="fas ${getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-info">
                    <h4>${activity.title}</h4>
                    <p>${activity.description}</p>
                </div>
                <div class="activity-time">${formatTime(activity.timestamp)}</div>
            `;
            
            activityList.appendChild(activityItem);
        });
    }

    // Get appropriate icon for activity type
    function getActivityIcon(type) {
        const icons = {
            'security': 'fa-shield-alt',
            'system': 'fa-cog',
            'alert': 'fa-bell',
            'update': 'fa-sync',
            'scan': 'fa-search',
            'backup': 'fa-save',
            'threat': 'fa-exclamation-triangle',
            'warning': 'fa-exclamation-circle'
        };
        return icons[type] || 'fa-info-circle';
    }

    // Format timestamp
    function formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
        return date.toLocaleDateString();
    }

    // Button click handlers
    refreshStatus.addEventListener('click', async () => {
        await updateSystemMetrics();
        await updateSecurityStatus();
        await updateActivityList();
        addActivity('system', 'System status refreshed');
    });

    runSecurityCheck.addEventListener('click', async () => {
        addActivity('security', 'Security check initiated');
        try {
            const response = await fetch('/api/security/check', { method: 'POST' });
            const result = await response.json();
            await updateSecurityStatus();
            addActivity('security', 'Security check completed');
        } catch (error) {
            addActivity('alert', 'Security check failed');
        }
    });

    scanSystem.addEventListener('click', async () => {
        addActivity('security', 'System scan started');
        try {
            const response = await fetch('/api/system/scan', { method: 'POST' });
            const result = await response.json();
            await updateSecurityStatus();
            addActivity('security', 'System scan completed');
        } catch (error) {
            addActivity('alert', 'System scan failed');
        }
    });

    backupSystem.addEventListener('click', async () => {
        addActivity('system', 'System backup started');
        try {
            const response = await fetch('/api/system/backup', { method: 'POST' });
            const result = await response.json();
            addActivity('system', 'System backup completed');
        } catch (error) {
            addActivity('alert', 'System backup failed');
        }
    });

    updateSystem.addEventListener('click', async () => {
        addActivity('update', 'Checking for updates');
        try {
            const response = await fetch('/api/system/updates', { method: 'POST' });
            const result = await response.json();
            addActivity('update', 'System is up to date');
        } catch (error) {
            addActivity('alert', 'Update check failed');
        }
    });

    optimizeSystem.addEventListener('click', async () => {
        addActivity('system', 'System optimization started');
        try {
            const response = await fetch('/api/system/optimize', { method: 'POST' });
            const result = await response.json();
            await updateSystemMetrics();
            addActivity('system', 'System optimization completed');
        } catch (error) {
            addActivity('alert', 'System optimization failed');
        }
    });

    // Initialize and start periodic updates
    updateSystemMetrics();
    updateSecurityStatus();
    updateActivityList();
    
    // Update metrics every 5 seconds
    setInterval(updateSystemMetrics, 5000);
    
    // Update security status every 10 seconds
    setInterval(updateSecurityStatus, 10000);
    
    // Update activities every 30 seconds
    setInterval(updateActivityList, 30000);
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        if (link.id !== 'logoutBtn') {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const href = link.getAttribute('href');
                if (href) {
                    window.location.href = href;
                }
            });
        }
    });
}

function initializeSecurityMetrics() {
    // Update security metrics with real data
    updateSecurityMetrics();
    
    // Set up periodic refresh
    setInterval(updateSecurityMetrics, 30000); // Refresh every 30 seconds
}

function updateSecurityMetrics() {
    // Get real security status
    const securityStatus = getRealSecurityStatus();
    
    // Update UI elements
    document.getElementById('securityStatus').textContent = securityStatus.status;
    document.getElementById('activeAlerts').textContent = securityStatus.activeAlerts;
    document.getElementById('systemHealth').textContent = securityStatus.systemHealth + '%';
}

function getRealSecurityStatus() {
    // Implement real security checks
    return {
        status: 'Protected',
        activeAlerts: 0,
        systemHealth: 100
    };
}

function initializeFinancialOverview() {
    // Initialize financial chart
    const ctx = document.getElementById('financeChart').getContext('2d');
    const financeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Income',
                data: [1200, 1900, 1500, 2000, 1800, 2200],
                borderColor: '#28a745',
                tension: 0.1
            }, {
                label: 'Expenses',
                data: [800, 1200, 1000, 1500, 1300, 1800],
                borderColor: '#dc3545',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                }
            }
        }
    });

    // Update financial metrics
    updateFinancialMetrics();
}

function updateFinancialMetrics() {
    // Get real financial data
    const financialData = getRealFinancialData();
    
    // Update UI elements
    document.getElementById('currentBalance').textContent = formatCurrency(financialData.currentBalance);
    document.getElementById('monthlyIncome').textContent = formatCurrency(financialData.monthlyIncome);
    document.getElementById('monthlyExpenses').textContent = formatCurrency(financialData.monthlyExpenses);
}

function getRealFinancialData() {
    // Implement real financial data retrieval
    return {
        currentBalance: 5000,
        monthlyIncome: 3000,
        monthlyExpenses: 2000
    };
}

function loadRecentActivity() {
    const activityList = document.getElementById('activityList');
    const activities = getRealTimeActivities();
    
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon">
                <i class="fas ${activity.icon}"></i>
            </div>
            <div class="activity-details">
                <p class="activity-description">${activity.description}</p>
                <span class="activity-time">${formatTime(activity.timestamp)}</span>
            </div>
        </div>
    `).join('');
}

function getRealTimeActivities() {
    // Implement real activity tracking
    return [
        {
            icon: 'fa-user-shield',
            description: 'Security scan completed',
            timestamp: new Date()
        },
        {
            icon: 'fa-wallet',
            description: 'New transaction recorded',
            timestamp: new Date(Date.now() - 3600000)
        },
        {
            icon: 'fa-bell',
            description: 'System update available',
            timestamp: new Date(Date.now() - 7200000)
        }
    ];
}

function setupEventListeners() {
    // Refresh button
    document.getElementById('refreshBtn').addEventListener('click', () => {
        updateSecurityMetrics();
        updateFinancialMetrics();
        loadRecentActivity();
    });

    // Add transaction button
    document.getElementById('addTransactionBtn').addEventListener('click', () => {
        // Implement transaction addition logic
        showTransactionModal();
    });

    // View all activities button
    document.getElementById('viewAllBtn').addEventListener('click', () => {
        // Implement view all activities logic
        showActivityHistory();
    });
}

function showTransactionModal() {
    // Implement transaction modal
    console.log('Show transaction modal');
}

function showActivityHistory() {
    // Implement activity history view
    console.log('Show activity history');
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatTime(timestamp) {
    return new Intl.DateTimeFormat('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    }).format(timestamp);
}

function getActivityIcon(type) {
    const icons = {
        'security': 'shield-alt',
        'finance': 'chart-line',
        'system': 'cog',
        'expense': 'receipt'
    };
    return icons[type] || 'info-circle';
}

function showError(message) {
    const error = document.createElement('div');
    error.className = 'alert alert-danger';
    error.innerHTML = `
        <i class="fas fa-exclamation-circle"></i>
        <strong>Error:</strong> ${message}
    `;
    document.body.appendChild(error);

    setTimeout(() => {
        error.remove();
    }, 5000);
}

// Add this function to handle logout
function handleLogout() {
    // Clear user session
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    
    // Redirect to landing page
    window.location.href = 'landing.html';
}

// Add system activity
function addSystemActivity(metrics) {
    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';
    
    activityItem.innerHTML = `
        <div class="activity-icon">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="activity-info">
            <h4>System Metrics Updated</h4>
            <p>CPU: ${metrics.cpu.usage}%, Memory: ${metrics.memory.usage}%, Storage: ${metrics.storage.usage}%</p>
        </div>
        <div class="activity-time">${formatTime(metrics.timestamp)}</div>
    `;
    
    activityList.insertBefore(activityItem, activityList.firstChild);
    
    // Keep only the last 5 activities
    if (activityList.children.length > 5) {
        activityList.removeChild(activityList.lastChild);
    }
} 